export default function HomePage() {
  return (
    <main className="flex items-center justify-center h-screen">
      <h1 className="text-4xl font-bold">Evolve Club is Live! 🎉</h1>
    </main>
  );
}
